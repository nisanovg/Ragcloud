---
title: Развертывание системы умного дома с использованием Node-RED и Mosquitto
source: Cloud.ru Evolution Tutorials
url: https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome
topic: compute
---
# Развертывание системы умного дома с использованием Node-RED и Mosquitto

С помощью этого руководства вы научитесь основам IoT-автоматизации и выполните проект по управлению температурой в умном доме.

Вы создадите виртуальную машину Ubuntu 22.04, разработаете и развернете на ней систему умного дома, которая будет управлять кондиционером в зависимости от температуры в помещении.

Вы будете использовать скрипты в качестве эмуляторов умных устройств, но полученные навыки можно применять и при работе с физическими устройствами.

Для взаимодействия со скриптами используется MQTT-брокер Mosquitto и программа Node-RED.
После того как эмулятор датчика публикует данные в определенный топик, центр управления или другие умные устройства получают MQTT-сообщения.
Node-RED подписывается на MQTT-сообщения, обрабатывает данные и запускает действия умных устройств.

В этом практическом руководстве эмулятор датчика выводит показатели температуры, Node-RED обрабатывает данные и включает или выключает кондиционер.

Вы будете использовать следующие сервисы:

- [Виртуальные машины](https://cloud.ru/docs/virtual-machines/ug/index)Виртуальные машины — сервис, в рамках которого предоставляется виртуальная машина для размещения приложения.
- [Публичный IP-адрес](https://cloud.ru/docs/public-ip/ug/topics/guides__allocate-ip)Публичный IP-адрес для доступа к сервису через интернет.
- [Node-RED](https://nodered.org/)Node-RED — программа для визуального проектирования автоматизаций.
- [Mosquitto](https://mosquitto.org/)Mosquitto — брокер MQTT для обмена сообщениями между умными устройствами.

[Виртуальные машины](https://cloud.ru/docs/virtual-machines/ug/index)Виртуальные машины — сервис, в рамках которого предоставляется виртуальная машина для размещения приложения.

[Публичный IP-адрес](https://cloud.ru/docs/public-ip/ug/topics/guides__allocate-ip)Публичный IP-адрес для доступа к сервису через интернет.

[Node-RED](https://nodered.org/)Node-RED — программа для визуального проектирования автоматизаций.

[Mosquitto](https://mosquitto.org/)Mosquitto — брокер MQTT для обмена сообщениями между умными устройствами.

Шаги:

1. [Разверните ресурсы в облаке](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Разверните ресурсы в облаке.
2. [Настройте окружение виртуальной машины](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Настройте окружение виртуальной машины.
3. [Настройте основные компоненты умного дома](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Настройте основные компоненты умного дома.
4. [Визуализируйте работу компонентов умного дома](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Визуализируйте работу компонентов умного дома.
5. [Протестируйте сценарий](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Протестируйте сценарий.

[Разверните ресурсы в облаке](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Разверните ресурсы в облаке.

[Настройте окружение виртуальной машины](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Настройте окружение виртуальной машины.

[Настройте основные компоненты умного дома](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Настройте основные компоненты умного дома.

[Визуализируйте работу компонентов умного дома](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Визуализируйте работу компонентов умного дома.

[Протестируйте сценарий](https://cloud.ru/docs/tutorials-evolution/list/topics/vm__smarthome)Протестируйте сценарий.

## Перед началом работы

1. [Зарегистрируйтесь в личном кабинете Cloud.ru](https://cloud.ru/docs/console/ug/topics/guides__registration)Зарегистрируйтесь в личном кабинете Cloud.ru.
Если вы уже зарегистрированы, [войдите под своей учетной записью](https://cloud.ru/docs/console/ug/topics/guides__auth)войдите под своей учетной записью.
2. [Сгенерируйте ключевую пару и загрузите публичный ключ](https://cloud.ru/docs/public-keys/ug/topics/quickstart)Сгенерируйте ключевую пару и загрузите публичный ключ в Cloud.ru Evolution.

[Зарегистрируйтесь в личном кабинете Cloud.ru](https://cloud.ru/docs/console/ug/topics/guides__registration)Зарегистрируйтесь в личном кабинете Cloud.ru.

Если вы уже зарегистрированы, [войдите под своей учетной записью](https://cloud.ru/docs/console/ug/topics/guides__auth)войдите под своей учетной записью.

[Сгенерируйте ключевую пару и загрузите публичный ключ](https://cloud.ru/docs/public-keys/ug/topics/quickstart)Сгенерируйте ключевую пару и загрузите публичный ключ в Cloud.ru Evolution.

## 1. Разверните ресурсы в облаке

На этом шаге вы подготовите сеть, группу безопасности, виртуальную машину.

1. [Создайте виртуальную сеть](https://cloud.ru/docs/evolution-vpc/ug/topics/guides__add-vpc)Создайте виртуальную сеть с названием vpc-home.
2. [Создайте подсеть](https://cloud.ru/docs/subnets/ug/topics/guides__create-subnet)Создайте подсеть со следующими параметрами:

Название — subnet-home.
VPC — vpc-home.
Адрес — 10.10.1.0/24.
DNS-серверы — 8.8.8.8.
3. [Создайте группу безопасности](https://cloud.ru/docs/security-groups/ug/topics/guides__create-sg)Создайте группу безопасности с названием sg-home и добавьте в нее правила:
 ТрафикПротоколПортТип источника/адресатаИсточник/АдресатВходящийTCP1883IP-адрес0.0.0.0/0ВходящийTCP1880IP-адрес0.0.0.0/0ВходящийTCP22IP-адрес0.0.0.0/0ИсходящийTCP1883IP-адрес0.0.0.0/0ИсходящийЛюбойЛюбойIP-адрес0.0.0.0/0
4. [Создайте виртуальную машину](https://cloud.ru/docs/virtual-machines/ug/topics/guides__create-vm)Создайте виртуальную машину со следующими параметрами:

Название — vm-home.
Образ — публичный образ Ubuntu 22.04.
Сетевой интерфейс — выберите тип Подсеть с публичным IP.
VPC — vpc-home.
Подсеть — subnet-home.
Публичный IP — оставьте Арендовать новый или выберите IP-адрес из списка арендованных.
Группы безопасности — добавьте sg-home.
Метод аутентификации — выберите Публичный ключ.
Публичный ключ — укажите ключ, созданный ранее.
Остальные параметры оставьте по умолчанию или выберите на свое усмотрение.

[Создайте виртуальную сеть](https://cloud.ru/docs/evolution-vpc/ug/topics/guides__add-vpc)Создайте виртуальную сеть с названием vpc-home.

[Создайте подсеть](https://cloud.ru/docs/subnets/ug/topics/guides__create-subnet)Создайте подсеть со следующими параметрами:

- Название — subnet-home.
- VPC — vpc-home.
- Адрес — 10.10.1.0/24.
- DNS-серверы — 8.8.8.8.

Название — subnet-home.

VPC — vpc-home.

Адрес — 10.10.1.0/24.

DNS-серверы — 8.8.8.8.

[Создайте группу безопасности](https://cloud.ru/docs/security-groups/ug/topics/guides__create-sg)Создайте группу безопасности с названием sg-home и добавьте в нее правила:

Трафик

Протокол

Порт

Тип источника/адресата

Источник/Адресат

Входящий

TCP

1883

IP-адрес

0.0.0.0/0

Входящий

TCP

1880

IP-адрес

0.0.0.0/0

Входящий

TCP

22

IP-адрес

0.0.0.0/0

Исходящий

TCP

1883

IP-адрес

0.0.0.0/0

Исходящий

Любой

Любой

IP-адрес

0.0.0.0/0

[Создайте виртуальную машину](https://cloud.ru/docs/virtual-machines/ug/topics/guides__create-vm)Создайте виртуальную машину со следующими параметрами:

- Название — vm-home.
- Образ — публичный образ Ubuntu 22.04.
- Сетевой интерфейс — выберите тип Подсеть с публичным IP.
- VPC — vpc-home.
- Подсеть — subnet-home.
- Публичный IP — оставьте Арендовать новый или выберите IP-адрес из списка арендованных.
- Группы безопасности — добавьте sg-home.
- Метод аутентификации — выберите Публичный ключ.
- Публичный ключ — укажите ключ, созданный ранее.
- Остальные параметры оставьте по умолчанию или выберите на свое усмотрение.

Название — vm-home.

Образ — публичный образ Ubuntu 22.04.

Сетевой интерфейс — выберите тип Подсеть с публичным IP.

VPC — vpc-home.

Подсеть — subnet-home.

Публичный IP — оставьте Арендовать новый или выберите IP-адрес из списка арендованных.

Группы безопасности — добавьте sg-home.

Метод аутентификации — выберите Публичный ключ.

Публичный ключ — укажите ключ, созданный ранее.

Остальные параметры оставьте по умолчанию или выберите на свое усмотрение.

Убедитесь, что ресурсы созданы и отображаются в личном кабинете:

1. На странице Сети → VPC отображается сеть vpc-home, а в списке ее подсетей — subnet-home.
2. На странице Сети → Группы безопасности отображается группа безопасности sg-home со статусом «Создана».
3. На странице Инфраструктура → Виртуальные машины отображается виртуальная машина vm-home со статусом «Запущена».

На странице Сети → VPC отображается сеть vpc-home, а в списке ее подсетей — subnet-home.

На странице Сети → Группы безопасности отображается группа безопасности sg-home со статусом «Создана».

На странице Инфраструктура → Виртуальные машины отображается виртуальная машина vm-home со статусом «Запущена».

## 2. Настройте окружение виртуальной машины

На этом шаге вы установите необходимые пакеты и подготовите среду системы умного дома.

1. [Подключитесь к виртуальной машине по SSH](https://cloud.ru/docs/virtual-machines/ug/topics/guides__ssh-connection)Подключитесь к виртуальной машине по SSH.
2. Обновите систему и установите утилиты:
sudo apt update && sudo apt upgrade -y
3. Установите пакетный менеджер pip и обновите его до последней версии:
sudo apt install -y python3-pip &&python3 -m pip install --upgrade pip
4. Установите Node.js и npm:
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -sudo apt install -y nodejs build-essential
5. Установите Node-RED:
sudo npm install -g --unsafe-perm node-red
6. Настройте автоматический запуск Node-RED:
sudo npm install -g pm2pm2 start $(which node-red) --name noderedpm2 save && pm2 startup
7. Установите Mosquitto:
sudo apt install -y mosquitto mosquitto-clientssudo systemctl enable mosquitto
8. Установите Python-библиотеку paho-mqtt для работы с MQTT-протоколом с разрешением на модификацию системных пакетов:
pip3 install paho-mqtt --break-system-packages

[Подключитесь к виртуальной машине по SSH](https://cloud.ru/docs/virtual-machines/ug/topics/guides__ssh-connection)Подключитесь к виртуальной машине по SSH.

Обновите систему и установите утилиты:

```bash
sudo
apt
update
&&
sudo
apt
upgrade
-y
```

Установите пакетный менеджер pip и обновите его до последней версии:

```bash
sudo
apt
install
-y
python3-pip
&&
python3
-m
pip
install
--upgrade
pip
```

Установите Node.js и npm:

```bash
curl
-fsSL
https://deb.nodesource.com/setup_18.x
|
sudo
-E
bash
-
sudo
apt
install
-y
nodejs build-essential
```

Установите Node-RED:

```bash
sudo
npm
install
-g
--unsafe-perm node-red
```

Настройте автоматический запуск Node-RED:

```bash
sudo
npm
install
-g
pm2
pm2 start
$(
which
node-red
)
--name
nodered
pm2 save
&&
pm2 startup
```

Установите Mosquitto:

```bash
sudo
apt
install
-y
mosquitto mosquitto-clients
sudo
systemctl
enable
mosquitto
```

Установите Python-библиотеку paho-mqtt для работы с MQTT-протоколом с разрешением на модификацию системных пакетов:

```bash
pip3
install
paho-mqtt --break-system-packages
```

## 3. Настройте основные компоненты умного дома

На этом шаге вы добавите компоненты умного дома — скрипты-эмуляторы датчика температуры и кондиционера.

1. Создайте директорию проекта и перейдите в нее:
mkdir smart_home && cd smart_home
2. Создайте файл temp_sensor.py:
nano temp_sensor.py
3. Добавьте в файл скрипт-эмулятор датчика температуры, который каждые 5 секунд генерирует случайный показатель температуры в диапазоне 18–35 °C.
import timeimport randomimport paho.mqtt.client as mqtt

broker = "localhost"topic = "/home/room1/temp"

client = mqtt.Client()client.connect(broker, 1883, 60)

while True: temp = round(random.uniform(18.0, 35.0), 1) print(f"[Sensor] Current temperature: {temp} °C") client.publish(topic, temp) time.sleep(5)

Где:

broker = "localhost" — указывает брокер.
Значение localhost используется, если Mosquitto установлен на той же машине, на которой запускается эмулятор.
topic = "/home/room1/temp" — указывает MQTT-топик, в который публикуется сгенерированный показатель.
4. Создайте файл ac_emulator.py:
nano ac_emulator.py
5. Добавьте в файл скрипт-эмулятор кондиционера, который подключается к Mosquitto и подписывается на MQTT-топик /home/room1/ac.
При получении сообщения скрипт выводит информацию о том, включен кондиционер или нет.
import paho.mqtt.client as mqtt

topic = "/home/room1/ac"

def on_connect(client, userdata, flags, rc): print("[AC] Connected with result code " + str(rc)) client.subscribe(topic)

def on_message(client, userdata, msg): command = msg.payload.decode() print(f"[AC] Received command: {command}") if command.upper() == "ON": print("[AC] ❄️ Air conditioner turned ON") elif command.upper() == "OFF": print("[AC] 🔕 Air conditioner turned OFF") else: print("[AC] ⚠️ Unknown command")

client = mqtt.Client()client.on_connect = on_connectclient.on_message = on_message

client.connect("localhost", 1883, 60)client.loop_forever()

Создайте директорию проекта и перейдите в нее:

```bash
mkdir
smart_home
&&
cd
smart_home
```

Создайте файл temp_sensor.py:

```bash
nano
temp_sensor.py
```

Добавьте в файл скрипт-эмулятор датчика температуры, который каждые 5 секунд генерирует случайный показатель температуры в диапазоне 18–35 °C.

```bash
import
time
import
random
import
paho
.
mqtt
.
client
as
mqtt
broker
=
"localhost"
topic
=
"/home/room1/temp"
client
=
mqtt
.
Client
(
)
client
.
connect
(
broker
,
1883
,
60
)
while
True
:
temp
=
round
(
random
.
uniform
(
18.0
,
35.0
)
,
1
)
print
(
f"[Sensor] Current temperature:
{
temp
}
°C"
)
client
.
publish
(
topic
,
temp
)
time
.
sleep
(
5
)
```

Где:

- broker = "localhost" — указывает брокер.
Значение localhost используется, если Mosquitto установлен на той же машине, на которой запускается эмулятор.
- topic = "/home/room1/temp" — указывает MQTT-топик, в который публикуется сгенерированный показатель.

broker = "localhost" — указывает брокер.
Значение localhost используется, если Mosquitto установлен на той же машине, на которой запускается эмулятор.

topic = "/home/room1/temp" — указывает MQTT-топик, в который публикуется сгенерированный показатель.

Создайте файл ac_emulator.py:

```bash
nano
ac_emulator.py
```

Добавьте в файл скрипт-эмулятор кондиционера, который подключается к Mosquitto и подписывается на MQTT-топик /home/room1/ac.
При получении сообщения скрипт выводит информацию о том, включен кондиционер или нет.

```bash
import
paho
.
mqtt
.
client
as
mqtt
topic
=
"/home/room1/ac"
def
on_connect
(
client
,
userdata
,
flags
,
rc
)
:
print
(
"[AC] Connected with result code "
+
str
(
rc
)
)
client
.
subscribe
(
topic
)
def
on_message
(
client
,
userdata
,
msg
)
:
command
=
msg
.
payload
.
decode
(
)
print
(
f"[AC] Received command:
{
command
}
"
)
if
command
.
upper
(
)
==
"ON"
:
print
(
"[AC] ❄️ Air conditioner turned ON"
)
elif
command
.
upper
(
)
==
"OFF"
:
print
(
"[AC] 🔕 Air conditioner turned OFF"
)
else
:
print
(
"[AC] ⚠️ Unknown command"
)
client
=
mqtt
.
Client
(
)
client
.
on_connect
=
on_connect
client
.
on_message
=
on_message
client
.
connect
(
"localhost"
,
1883
,
60
)
client
.
loop_forever
(
)
```

## 4. Визуализируйте работу компонентов умного дома

На этом шаге вы настроите узлы блок-схемы в Node-RED, чтобы создать сценарий работы умного дома.

1. На компьютере откройте браузер и перейдите по адресу http://<ip_address>:1880/, где <ip_address> — публичный IP-адрес виртуальной машины.
Откроется веб-интерфейс Node-RED.
2. Перетащите в рабочую область следующие узлы:

mqtt in
function
mqtt out
3. Настройте узел mqtt in:

В рабочей области дважды нажмите на первый элемент mqtt.
В открывшемся окне справа от поля Сервер нажмите +.
Укажите параметры:

Имя — my_server.
Адрес — localhost.
Порт — 1883.

Нажмите Добавить.
Укажите остальные параметры узла:

Тема — /home/room1/temp.
Quality of Service (QoS) — 0.
Имя — Температура.

Нажмите Готово.
4. Настройте узел function, чтобы он сравнивал температуру с пороговыми значениями и отправлял кондиционеру команду ON или OFF.

В рабочей области дважды нажмите на элемент function.
В поле Имя введите значение Порог температуры.
На вкладке Функция в поле ввода вставьте код:
let temp = parseFloat(msg.payload);if (temp > 26) { msg.payload = "ON";} else { msg.payload = "OFF";}return msg;
5. Настройте узел mqtt out.

Дважды нажмите на второй элемент mqtt.
Укажите следующие значения параметров:

Сервер — my_server;
Тема — /home/room1/ac;
Имя — Кондиционер.

Нажмите Готово.
6. Соедините узлы.

На компьютере откройте браузер и перейдите по адресу http://<ip_address>:1880/, где <ip_address> — публичный IP-адрес виртуальной машины.

Откроется веб-интерфейс Node-RED.

Перетащите в рабочую область следующие узлы:

- mqtt in
- function
- mqtt out

mqtt in

function

mqtt out

![../_images/node-red-add-nodes.png](https://cloud.ru/docs/api/cdn/tutorials-evolution/list/_images/node-red-add-nodes.png)

Настройте узел mqtt in:

1. В рабочей области дважды нажмите на первый элемент mqtt.
2. В открывшемся окне справа от поля Сервер нажмите +.
3. Укажите параметры:

Имя — my_server.
Адрес — localhost.
Порт — 1883.
4. Нажмите Добавить.
5. Укажите остальные параметры узла:

Тема — /home/room1/temp.
Quality of Service (QoS) — 0.
Имя — Температура.
6. Нажмите Готово.

В рабочей области дважды нажмите на первый элемент mqtt.

В открывшемся окне справа от поля Сервер нажмите +.

Укажите параметры:

- Имя — my_server.
- Адрес — localhost.
- Порт — 1883.

Имя — my_server.

Адрес — localhost.

Порт — 1883.

Нажмите Добавить.

Укажите остальные параметры узла:

- Тема — /home/room1/temp.
- Quality of Service (QoS) — 0.
- Имя — Температура.

Тема — /home/room1/temp.

Quality of Service (QoS) — 0.

Имя — Температура.

Нажмите Готово.

Настройте узел function, чтобы он сравнивал температуру с пороговыми значениями и отправлял кондиционеру команду ON или OFF.

1. В рабочей области дважды нажмите на элемент function.
2. В поле Имя введите значение Порог температуры.
3. На вкладке Функция в поле ввода вставьте код:
let temp = parseFloat(msg.payload);if (temp > 26) { msg.payload = "ON";} else { msg.payload = "OFF";}return msg;

В рабочей области дважды нажмите на элемент function.

В поле Имя введите значение Порог температуры.

На вкладке Функция в поле ввода вставьте код:

```bash
let
temp
=
parseFloat
(
msg.payload
)
;
if
(
temp
>
26
)
{
msg.payload
=
"ON"
;
}
else
{
msg.payload
=
"OFF"
;
}
return
msg
;
```

Настройте узел mqtt out.

1. Дважды нажмите на второй элемент mqtt.
2. Укажите следующие значения параметров:

Сервер — my_server;
Тема — /home/room1/ac;
Имя — Кондиционер.
3. Нажмите Готово.

Дважды нажмите на второй элемент mqtt.

Укажите следующие значения параметров:

- Сервер — my_server;
- Тема — /home/room1/ac;
- Имя — Кондиционер.

Сервер — my_server;

Тема — /home/room1/ac;

Имя — Кондиционер.

Нажмите Готово.

Соедините узлы.

![../_images/node-red-link-nodes.png](https://cloud.ru/docs/api/cdn/tutorials-evolution/list/_images/node-red-link-nodes.png)

## 5. Протестируйте сценарий

На этом шаге вы запустите скрипты-эмуляторы умных устройств, чтобы протестировать сценарий.

1. Откройте два окна терминала.
В обоих окнах подключитесь по SSH к виртуальной машине vm-home.
2. В одном терминале запустите эмулятор датчика температуры:
python3 temp_sensor.py
3. Во втором терминале запустите эмулятор кондиционера:
python3 ac_emulator.py
4. На странице Node-RED http://<ip_address>:1880/ нажмите Развернуть.
5. Откройте терминал с запущенным эмулятором кондиционера.

Откройте два окна терминала.
В обоих окнах подключитесь по SSH к виртуальной машине vm-home.

В одном терминале запустите эмулятор датчика температуры:

```bash
python3 temp_sensor.py
```

Во втором терминале запустите эмулятор кондиционера:

```bash
python3 ac_emulator.py
```

На странице Node-RED http://<ip_address>:1880/ нажмите Развернуть.

Откройте терминал с запущенным эмулятором кондиционера.

В терминале будет отображаться информация о включении и выключении кондиционера в зависимости от полученной из топика температуры.

## Результат

Вы настроили рабочий поток на основе MQTT-сообщений.
В пределах этого потока сервер умного дома Node-RED отслеживает изменения полученной с датчика температуры информации и при необходимости включает или выключает кондиционер.

Далее вы можете настроить отправку сообщений о температуре и состоянии кондиционера в Telegram.
