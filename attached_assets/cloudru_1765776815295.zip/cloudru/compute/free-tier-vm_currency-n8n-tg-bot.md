---
title: No-code автоматизация рассылки курса валют в Telegram с помощью n8n
source: Cloud.ru Evolution Tutorials
url: https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot
topic: compute
---
# No-code автоматизация рассылки курса валют в Telegram с помощью n8n

С помощью этого руководства вы научитесь разворачивать no-code платформу n8n на виртуальной машине, настраивать процессы автоматизации и создавать Telegram-бота.

Вы будете использовать следующие сервисы:

- [Виртуальная машина free tier](https://cloud.ru/docs/virtual-machines/ug/topics/overview__free-tier)Виртуальная машина free tier — сервис, в рамках которого предоставляется бесплатная виртуальная машина с готовой конфигурацией.
- [Публичный IP-адрес](https://cloud.ru/docs/public-ip/ug/topics/guides__allocate-ip)Публичный IP-адрес для доступа к машине из интернета и организации работы с Telegram.
- [Docker](https://docs.docker.com/)Docker — система контейнеризации.
- [Docker Compose](https://docs.docker.com/compose)Docker Compose — инструмент для запуска и управления Docker-контейнерами.
- [n8n](https://n8n.io/)n8n — платформа с открытым кодом для автоматизации рабочих процессов и интеграции сервисов. Подходит для экспериментов и пет-проектов.
- [BotFather](https://t.me/BotFather)BotFather — Telegram-бот для создания ботов.

[Виртуальная машина free tier](https://cloud.ru/docs/virtual-machines/ug/topics/overview__free-tier)Виртуальная машина free tier — сервис, в рамках которого предоставляется бесплатная виртуальная машина с готовой конфигурацией.

[Публичный IP-адрес](https://cloud.ru/docs/public-ip/ug/topics/guides__allocate-ip)Публичный IP-адрес для доступа к машине из интернета и организации работы с Telegram.

[Docker](https://docs.docker.com/)Docker — система контейнеризации.

[Docker Compose](https://docs.docker.com/compose)Docker Compose — инструмент для запуска и управления Docker-контейнерами.

[n8n](https://n8n.io/)n8n — платформа с открытым кодом для автоматизации рабочих процессов и интеграции сервисов. Подходит для экспериментов и пет-проектов.

[BotFather](https://t.me/BotFather)BotFather — Telegram-бот для создания ботов.

Шаги:

1. [Разверните ресурсы в облаке](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Разверните ресурсы в облаке.
2. [Настройте окружение виртуальной машины](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Настройте окружение виртуальной машины.
3. [Разверните Docker-контейнер с n8n для проекта](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Разверните Docker-контейнер с n8n для проекта.
4. [Зарегистрируйте бота в Telegram](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Зарегистрируйте бота в Telegram.
5. [Создайте поток для отправки сообщения на портале n8n](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Создайте поток для отправки сообщения на портале n8n.
6. [Протестируйте работу бота](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Протестируйте работу бота.

[Разверните ресурсы в облаке](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Разверните ресурсы в облаке.

[Настройте окружение виртуальной машины](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Настройте окружение виртуальной машины.

[Разверните Docker-контейнер с n8n для проекта](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Разверните Docker-контейнер с n8n для проекта.

[Зарегистрируйте бота в Telegram](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Зарегистрируйте бота в Telegram.

[Создайте поток для отправки сообщения на портале n8n](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Создайте поток для отправки сообщения на портале n8n.

[Протестируйте работу бота](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)Протестируйте работу бота.

## Перед началом работы

[Зарегистрируйтесь в личном кабинете Cloud.ru](https://cloud.ru/docs/console/ug/topics/guides__registration)Зарегистрируйтесь в личном кабинете Cloud.ru.

Если вы уже зарегистрированы, [войдите под своей учетной записью](https://cloud.ru/docs/console/ug/topics/guides__auth)войдите под своей учетной записью.

## 1. Разверните ресурсы в облаке

На этом шаге вы создадите бесплатную виртуальную машину и назначите ей публичный IP-адрес с заданными настройками трафика.

1. [Создайте бесплатную виртуальную машину](https://cloud.ru/docs/virtual-machines/ug/topics/guides__create-free-tier-vm)Создайте бесплатную виртуальную машину со следующими параметрами:

Название — например currenсу-bot-server.
Публичный образ с Ubuntu 22.04.
Публичный IP — оставьте Арендовать новый или выберите IP-адрес из списка арендованных.
Логин — оставьте значение по умолчанию или укажите новый.
Метод аутентификации — Публичный ключ и Пароль.
Публичный ключ — укажите ключ, созданный ранее.
Пароль — задайте пароль пользователя.
Имя хоста — currenсуbot.
Остальные параметры оставьте по умолчанию или выберите на свое усмотрение.

Убедитесь, что в личном кабинете на странице Инфраструктура → Виртуальные машины отображается виртуальная машина со статусом «Запущена» и назначенным публичным IP-адресом.
2. Уточните [зону доступности](https://cloud.ru/docs/glossary/list/index)зону доступности, в которой была создана виртуальная машина.
3. [Создайте группу безопасности](https://cloud.ru/docs/security-groups/ug/topics/guides__create-sg)Создайте группу безопасности с названием currency-bot в той же зоне доступности и добавьте в нее правила:
 ТрафикПротоколПортТип источника/адресатаИсточник/АдресатВходящийTCP22IP-адрес0.0.0.0/0ВходящийTCP5678IP-адрес0.0.0.0/0ИсходящийTCP80IP-адрес0.0.0.0/0ИсходящийTCP443IP-адрес0.0.0.0/0
4. [Назначьте созданную группу безопасности виртуальной машине](https://cloud.ru/docs/virtual-machines/ug/topics/guides__add-to-sg)Назначьте созданную группу безопасности виртуальной машине.

[Создайте бесплатную виртуальную машину](https://cloud.ru/docs/virtual-machines/ug/topics/guides__create-free-tier-vm)Создайте бесплатную виртуальную машину со следующими параметрами:

- Название — например currenсу-bot-server.
- Публичный образ с Ubuntu 22.04.
- Публичный IP — оставьте Арендовать новый или выберите IP-адрес из списка арендованных.
- Логин — оставьте значение по умолчанию или укажите новый.
- Метод аутентификации — Публичный ключ и Пароль.
- Публичный ключ — укажите ключ, созданный ранее.
- Пароль — задайте пароль пользователя.
- Имя хоста — currenсуbot.
- Остальные параметры оставьте по умолчанию или выберите на свое усмотрение.

Название — например currenсу-bot-server.

Публичный образ с Ubuntu 22.04.

Публичный IP — оставьте Арендовать новый или выберите IP-адрес из списка арендованных.

Логин — оставьте значение по умолчанию или укажите новый.

Метод аутентификации — Публичный ключ и Пароль.

Публичный ключ — укажите ключ, созданный ранее.

Пароль — задайте пароль пользователя.

Имя хоста — currenсуbot.

Остальные параметры оставьте по умолчанию или выберите на свое усмотрение.

Убедитесь, что в личном кабинете на странице Инфраструктура → Виртуальные машины отображается виртуальная машина со статусом «Запущена» и назначенным публичным IP-адресом.

Уточните

[Создайте группу безопасности](https://cloud.ru/docs/security-groups/ug/topics/guides__create-sg)Создайте группу безопасности с названием currency-bot в той же зоне доступности и добавьте в нее правила:

Трафик

Протокол

Порт

Тип источника/адресата

Источник/Адресат

Входящий

TCP

22

IP-адрес

0.0.0.0/0

Входящий

TCP

5678

IP-адрес

0.0.0.0/0

Исходящий

TCP

80

IP-адрес

0.0.0.0/0

Исходящий

TCP

443

IP-адрес

0.0.0.0/0

[Назначьте созданную группу безопасности виртуальной машине](https://cloud.ru/docs/virtual-machines/ug/topics/guides__add-to-sg)Назначьте созданную группу безопасности виртуальной машине.

## 2. Настройте окружение виртуальной машины

На этом шаге вы установите необходимые пакеты и подготовите среду для n8n.

1. [Подключитесь к виртуальной машине по SSH](https://cloud.ru/docs/virtual-machines/ug/topics/guides__ssh-connection)Подключитесь к виртуальной машине по SSH.
2. Обновите систему и установите утилиты:
sudo apt update && sudo apt upgrade -y

[Подключитесь к виртуальной машине по SSH](https://cloud.ru/docs/virtual-machines/ug/topics/guides__ssh-connection)Подключитесь к виртуальной машине по SSH.

Обновите систему и установите утилиты:

```bash
sudo
apt
update
&&
sudo
apt
upgrade
-y
```

Добавьте настройки DNS для разрешения доменных имен:

1. Откройте файл /etc/resolv.conf для редактирования:
sudo nano /etc/resolv.conf
2. Добавьте следующие настройки и сохраните файл:
nameserver 8.8.8.8nameserver 8.8.4.4
3. [Перезагрузите виртуальную машину](https://cloud.ru/docs/virtual-machines/ug/topics/guides__restart)Перезагрузите виртуальную машину и подключитесь к ней по SSH.

Откройте файл /etc/resolv.conf для редактирования:

```bash
sudo
nano
/etc/resolv.conf
```

Добавьте следующие настройки и сохраните файл:

```bash
nameserver 8.8.8.8
nameserver 8.8.4.4
```

[Перезагрузите виртуальную машину](https://cloud.ru/docs/virtual-machines/ug/topics/guides__restart)Перезагрузите виртуальную машину и подключитесь к ней по SSH.

Подготовьте систему к безопасной установке Docker, добавив официальный репозиторий и настроив механизмы проверки подлинности пакетов:

```bash
sudo
apt-get
install
ca-certificates
curl
-y
sudo
install
-m
0755
-d
/etc/apt/keyrings
sudo
curl
-fsSL
https://download.docker.com/linux/ubuntu/gpg
-o
/etc/apt/keyrings/docker.asc
sudo
chmod
a+r /etc/apt/keyrings/docker.asc
```

1. Установите Docker, Docker Compose и сопутствующее ПО:

sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y
2. Добавьте текущего пользователя виртуальной машины в группу Docker:

Выполните команду:
sudo usermod -aG docker $USERnewgrp docker

Перезагрузите систему.
Проверьте работоспособность Docker:
docker run hello-world

Появится сообщение, подтверждающее успешность установки и настройки.

ПримечаниеВ некоторых случаях права на использование Docker без префикса sudo не сохраняются и командная строка возвращает ошибку permission denied.
В этом случае вы можете продолжить работу с Docker, добавляя в начало каждой команды префикс sudo.

Установите Docker, Docker Compose и сопутствующее ПО:

```bash
sudo
apt-get
install
docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
-y
```

Добавьте текущего пользователя виртуальной машины в группу Docker:

1. Выполните команду:
sudo usermod -aG docker $USERnewgrp docker
2. Перезагрузите систему.
3. Проверьте работоспособность Docker:
docker run hello-world

Появится сообщение, подтверждающее успешность установки и настройки.

Выполните команду:

```bash
sudo
usermod
-aG
docker
$USER
newgrp
docker
```

Перезагрузите систему.

Проверьте работоспособность Docker:

```bash
docker
run hello-world
```

Появится сообщение, подтверждающее успешность установки и настройки.

В некоторых случаях права на использование Docker без префикса sudo не сохраняются и командная строка возвращает ошибку permission denied.
В этом случае вы можете продолжить работу с Docker, добавляя в начало каждой команды префикс sudo.

## 3. Разверните Docker-контейнер с n8n для проекта

На этом шаге вы развернете n8n.

1. Создайте папку проекта и перейдите в нее:
mkdir ~/n8n && cd ~/n8n
2. Создайте файл манифеста для Docker-контейнера:
nano docker-compose.yml
3. Вставьте следующую конфигурацию:
services: n8n: image: n8nio/n8n:latest restart: unless-stopped ports: - "5678:5678" environment: - N8N_BASIC_AUTH_ACTIVE=true - N8N_BASIC_AUTH_USER=admin - N8N_BASIC_AUTH_PASSWORD=adminpass - N8N_SECURE_COOKIE=false volumes: - n8n_data:/home/node/.n8n

volumes: n8n_data:
4. Запустите n8n, выполнив команду:
docker compose up -d
5. Проверьте работу n8n.

В браузере перейдите по ссылке http://<IP_address>:5678, где <IP_address> — это публичный IP-адрес вашей виртуальной машины.
Создайте учетную запись n8n или войдите под уже существующей.

После создания учетной записи откроется портал n8n.

Создайте папку проекта и перейдите в нее:

```bash
mkdir
~/n8n
&&
cd
~/n8n
```

Создайте файл манифеста для Docker-контейнера:

```bash
nano
docker-compose.yml
```

Вставьте следующую конфигурацию:

```bash
services
:
n8n
:
image
:
n8nio/n8n
:
latest
restart
:
unless
-
stopped
ports
:
-
"5678:5678"
environment
:
-
N8N_BASIC_AUTH_ACTIVE=true
-
N8N_BASIC_AUTH_USER=admin
-
N8N_BASIC_AUTH_PASSWORD=adminpass
-
N8N_SECURE_COOKIE=false
volumes
:
-
n8n_data
:
/home/node/.n8n
volumes
:
n8n_data
:
```

Запустите n8n, выполнив команду:

```bash
docker
compose up
-d
```

Проверьте работу n8n.

1. В браузере перейдите по ссылке http://<IP_address>:5678, где <IP_address> — это публичный IP-адрес вашей виртуальной машины.
2. Создайте учетную запись n8n или войдите под уже существующей.

В браузере перейдите по ссылке http://<IP_address>:5678, где <IP_address> — это публичный IP-адрес вашей виртуальной машины.

Создайте учетную запись n8n или войдите под уже существующей.

После создания учетной записи откроется портал n8n.

## 4. Зарегистрируйте бота в Telegram

На этом шаге вы зарегистрируете в Telegram нового бота и получите его токен.

1. В Telegram найдите бота BotFather.
2. Выполните команду /newbot.
3. Задайте имя (name) и имя пользователя (username) для бота.
Имя пользователя должно заканчиваться на Bot или _bot.
В результате регистрации BotFather сообщит токен бота.
Сохраните его, он понадобится далее.
4. Убедитесь, что созданный бот отображается в Telegram при поиске по имени.
5. Откройте диалог с созданным ботом и нажмите Start или напишите в диалог сообщение /start, чтобы запустить его.
6. В диалог с ботом отправьте любое сообщение, например привет.
Если бот не возвращает ответ, отправьте еще несколько сообщений.
7. В терминале вашей виртуальной машины выполните запрос:
curl https://api.telegram.org/bot<your_token>/getUpdates

Полученный ответ должен выглядеть следующим образом:
{"ok":true,"result":[{"update_id":654369611,"message":{"message_id":2,"from":{"id":989698711,"is_bot":false
8. Скопируйте и сохраните числовой идентификатор с признаком is_bot — в примере это 989698711.

В Telegram найдите бота BotFather.

Выполните команду /newbot.

Задайте имя (name) и имя пользователя (username) для бота.

Имя пользователя должно заканчиваться на Bot или _bot.

В результате регистрации BotFather сообщит токен бота.
Сохраните его, он понадобится далее.

Убедитесь, что созданный бот отображается в Telegram при поиске по имени.

Откройте диалог с созданным ботом и нажмите Start или напишите в диалог сообщение /start, чтобы запустить его.

В диалог с ботом отправьте любое сообщение, например привет.
Если бот не возвращает ответ, отправьте еще несколько сообщений.

В терминале вашей виртуальной машины выполните запрос:

```bash
curl
https://api.telegram.org/bot
<
your_token
>
/getUpdates
```

Полученный ответ должен выглядеть следующим образом:

```bash
{
"ok"
:
true
,
"result"
:
[
{
"update_id"
:
654369611
,
"message"
:
{
"message_id"
:
2
,
"from"
:
{
"id"
:
989698711
,
"is_bot"
:
false
```

Скопируйте и сохраните числовой идентификатор с признаком is_bot — в примере это 989698711.

## 5. Создайте поток для отправки сообщения на портале n8n

На этом шаге вы создадите рабочий сценарий, в результате которого сервер n8n будет получать актуальный курс валют с сайта ЦБ РФ и отправлять в Telegram.

1. В браузере перейдите по ссылке http://<IP_address>:5678.
2. Нажмите Create Workflow.
3. Добавьте узел, который будет определять расписание отправки сообщений.

Нажмите Add First Step и выберите On a schedule.
В поле Trigger Interval выберите Custom (Cron).
В открывшемся поле введите значение 0 9 * * * для запуска каждый день в 09:00.
В верхней части окна настройки расписания нажмите activate, чтобы включить выполнение запроса по расписанию.
В левом верхнем углу нажмите Back to canvas.
4. Добавьте узел, который будет получать информацию с сайта ЦБ РФ.

Справа от предыдущего элемента нажмите + и выберите HTTP Request.
В поле URL введите значение: https://www.cbr-xml-daily.ru/daily_json.js.
Выполнение этого запроса возвращает данные от ЦБ РФ о курсах валют в формате JSON.
Нажмите Add option и выберите Response.
В поле Response Format выберите JSON.
В левом верхнем углу нажмите Back to canvas.
5. Добавьте узел, который будет обрабатывать и форматировать полученные данные.

Справа от предыдущего элемента нажмите + и выберите Code → Code in JavaScript.
В поле Code вставьте код:
// Receive data from the previous nodeconst response = $input.all()[0].json;

// Extract exchange ratesconst usdRate = response.Valute.USD.Value;const eurRate = response.Valute.EUR.Value;

// Format the resultreturn {text: `💱 Курс валют от ЦБ РФ:🇺🇸 USD: ${usdRate.toFixed(2)}₽🇪🇺 EUR: ${eurRate.toFixed(2)}₽`};

В левом верхнем углу нажмите Back to canvas.
6. Добавьте узел, который будет отправлять сообщение в Telegram.

Справа от предыдущего элемента нажмите + и выберите Telegram → Send a text message.
В поле Credential to connect with выберите Create new credentials.
В поле Access Token вставьте API-токен вашего бота, полученный от BotFather.
В правом верхем углу нажмите Save и закройте окно добавления токена.
В поле Resource выберите Message.
В поле Operation выберите Send Message.
В поле Chat ID укажите числовой идентификатор чата, полученный [на предыдущем шаге](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)на предыдущем шаге.
В примере это 989698711.
В поле Text выберите режим Expression и введите {{ $json["text"] }}.
В левом верхнем углу нажмите Back to canvas.

В браузере перейдите по ссылке http://<IP_address>:5678.

Нажмите Create Workflow.

Добавьте узел, который будет определять расписание отправки сообщений.

1. Нажмите Add First Step и выберите On a schedule.
2. В поле Trigger Interval выберите Custom (Cron).
3. В открывшемся поле введите значение 0 9 * * * для запуска каждый день в 09:00.
4. В верхней части окна настройки расписания нажмите activate, чтобы включить выполнение запроса по расписанию.
5. В левом верхнем углу нажмите Back to canvas.

Нажмите Add First Step и выберите On a schedule.

В поле Trigger Interval выберите Custom (Cron).

В открывшемся поле введите значение 0 9 * * * для запуска каждый день в 09:00.

В верхней части окна настройки расписания нажмите activate, чтобы включить выполнение запроса по расписанию.

В левом верхнем углу нажмите Back to canvas.

Добавьте узел, который будет получать информацию с сайта ЦБ РФ.

1. Справа от предыдущего элемента нажмите + и выберите HTTP Request.
2. В поле URL введите значение: https://www.cbr-xml-daily.ru/daily_json.js.
Выполнение этого запроса возвращает данные от ЦБ РФ о курсах валют в формате JSON.
3. Нажмите Add option и выберите Response.
4. В поле Response Format выберите JSON.
5. В левом верхнем углу нажмите Back to canvas.

Справа от предыдущего элемента нажмите + и выберите HTTP Request.

В поле URL введите значение: https://www.cbr-xml-daily.ru/daily_json.js.
Выполнение этого запроса возвращает данные от ЦБ РФ о курсах валют в формате JSON.

Нажмите Add option и выберите Response.

В поле Response Format выберите JSON.

В левом верхнем углу нажмите Back to canvas.

Добавьте узел, который будет обрабатывать и форматировать полученные данные.

1. Справа от предыдущего элемента нажмите + и выберите Code → Code in JavaScript.
2. В поле Code вставьте код:
// Receive data from the previous nodeconst response = $input.all()[0].json;

// Extract exchange ratesconst usdRate = response.Valute.USD.Value;const eurRate = response.Valute.EUR.Value;

// Format the resultreturn {text: `💱 Курс валют от ЦБ РФ:🇺🇸 USD: ${usdRate.toFixed(2)}₽🇪🇺 EUR: ${eurRate.toFixed(2)}₽`};
3. В левом верхнем углу нажмите Back to canvas.

Справа от предыдущего элемента нажмите + и выберите Code → Code in JavaScript.

В поле Code вставьте код:

```bash
// Receive data from the previous
node
const response
=
$input
.all
(
)
[
0
]
.json
;
// Extract exchange rates
const usdRate
=
response.Valute.USD.Value
;
const eurRate
=
response.Valute.EUR.Value
;
// Format the result
return
{
text:
`
💱 Курс валют от ЦБ РФ:
🇺🇸 USD: $
{
usdRate.toFixed
(
2
)
}
₽
🇪🇺 EUR: $
{
eurRate.toFixed
(
2
)
}
₽
`
}
;
```

В левом верхнем углу нажмите Back to canvas.

Добавьте узел, который будет отправлять сообщение в Telegram.

1. Справа от предыдущего элемента нажмите + и выберите Telegram → Send a text message.
2. В поле Credential to connect with выберите Create new credentials.
3. В поле Access Token вставьте API-токен вашего бота, полученный от BotFather.
4. В правом верхем углу нажмите Save и закройте окно добавления токена.
5. В поле Resource выберите Message.
6. В поле Operation выберите Send Message.
7. В поле Chat ID укажите числовой идентификатор чата, полученный [на предыдущем шаге](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)на предыдущем шаге.
В примере это 989698711.
8. В поле Text выберите режим Expression и введите {{ $json["text"] }}.
9. В левом верхнем углу нажмите Back to canvas.

Справа от предыдущего элемента нажмите + и выберите Telegram → Send a text message.

В поле Credential to connect with выберите Create new credentials.

В поле Access Token вставьте API-токен вашего бота, полученный от BotFather.

В правом верхем углу нажмите Save и закройте окно добавления токена.

В поле Resource выберите Message.

В поле Operation выберите Send Message.

В поле Chat ID укажите числовой идентификатор чата, полученный [на предыдущем шаге](https://cloud.ru/docs/tutorials-evolution/list/topics/free-tier-vm__currency-n8n-tg-bot)на предыдущем шаге.
В примере это 989698711.

В поле Text выберите режим Expression и введите {{ $json["text"] }}.

В левом верхнем углу нажмите Back to canvas.

Созданный поток будет выглядеть следующим образом:

![../_images/img__currency_n8n_workflow.png](https://cloud.ru/docs/api/cdn/tutorials-evolution/list/_images/img__currency_n8n_workflow.png)

## 6. Протестируйте работу бота

Чтобы протестировать работу потока, в нижней части рабочей области n8n нажмите Execute workflow.
В бот придет сообщение с курсом валют от ЦБ РФ:

![../_images/img__currency_tg_results.png](https://cloud.ru/docs/api/cdn/tutorials-evolution/list/_images/img__currency_tg_results.png)

## Результат

Вы развернули и настроили платформу для автоматизации n8n на виртуальной машине, создали Telegram-бот для отправки сообщений и рабочий сценарий, в результате которого сервер n8n получает курсы валют с сайта ЦБ РФ и отправляет их в Telegram.

В дальнейшем вы можете развить этот проект, добавив возможность запрашивать через Telegram-бот курс Bitcoin, который нужно будет получать из другого источника.
